(function () {
	document.addEventListener("click", function(event) {
		if (event.target.classList.contains("side-nav__brand")) {
			// do stuff
			window.open("http://selenium-toolkit.com/solutions/")
		}
	});
})();
